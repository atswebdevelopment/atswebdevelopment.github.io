# BHG
2021 website

To build the project:
`npm install`

To monitor style and script changes:
`npm run watch`

To run a local version of the site:
`npm run serve`